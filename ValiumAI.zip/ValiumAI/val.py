# val lives

from val_scripts import val

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: python val.py script_name [args...]")
        sys.exit(1)

    script_name = sys.argv[1]
    try:
        args = sys.argv[2:]
        output = val(script_name, *args)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    print(output.decode())
    

# To use this script, simply run python val.py script_name [args...] in the terminal. Replace script_name with the name of the Val script you want to execute, and replace [args...] with any arguments required by the script.

# For example, if you have a Val script named greet.py that accepts a name as an argument, you can run python val.py greet John to execute the script with the argument John.

# If you want to use this script as the main command of your program, you can rename it to match the desired command name, and make sure it is in a directory that is included in your PATH environment variable.