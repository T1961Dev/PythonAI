import os

# Langchain configuration
LANGCHAIN_URL = 'https://api.langchain.com/v1'
LANGCHAIN_TIMEOUT = 30

# internet access configuration
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# AI agent configuration
AI_AGENT_NAME = 'My AI Agent'
AI_AGENT_VERSION = '1.0.0'
AI_AGENT_DESCRIPTION = 'This is a description of my AI agent.'

# database configuration
DATABASE_URI = 'sqlite:///mydatabase.db'
DATABASE_ECHO = False

# API keys and secrets
OPENAI_API_KEY = 'my-openai-api-key'
GOOGLE_CLOUD_PROJECT_ID = 'my-google-cloud-project-id'

# logging configuration
LOGGING_LEVEL = logging.DEBUG
LOGGING_FORMAT = '%(asctime)s - %(levelname)s - %(message)s'

# path configuration
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
LOG_DIR = os.path.join(os.path.dirname(__file__), 'logs')

# model configuration
MODEL_NAME = 'my-model'
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'models', MODEL_NAME)

# GUI configuration
GUI_TITLE = 'My AI Agent'
GUI_WIDTH = 800
GUI_HEIGHT = 600
