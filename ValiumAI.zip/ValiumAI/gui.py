import tkinter as tk
from utils import create_file, execute_command, get_environment_details, runValScript, runLangchain
from config import AI_AGENT_NAME, AI_AGENT_VERSION, AI_AGENT_DESCRIPTION, GUI_TITLE, GUI_WIDTH, GUI_HEIGHT, config

# Initialize the main window
root = tk.Tk()
root.title(GUI_TITLE)
root.geometry(f"{GUI_WIDTH}x{GUI_HEIGHT}")

# Create input fields, buttons, and a text area
input_field = tk.Entry(root, width=50)
input_field.pack()

output_text = tk.Text(root, height=10, width=50)
output_text.pack()

def run_local_model():
    text = input_field.get()
    output_text.delete('1.0', tk.END)
    output_text.insert(tk.END, runLangchain(text, 'local'))

run_button = tk.Button(root, text="Run Local Model", command=run_local_model)
run_button.pack()

# Configure the AI agent
server = LangchainServer()
server.config.from_object(config)
server.config['AI_AGENT_NAME'] = AI_AGENT_NAME
server.config['AI_AGENT_VERSION'] = AI_AGENT_VERSION
server.config['AI_AGENT_DESCRIPTION'] = AI_AGENT_DESCRIPTION

# Run the main loop
root.mainloop()