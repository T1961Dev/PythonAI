from langchain.server import LangchainServer
from utils import create_file, execute_command, get_environment_details, runValScript, runLangchain
from config import AI_AGENT_NAME, AI_AGENT_VERSION, AI_AGENT_DESCRIPTION, GUI_TITLE, GUI_WIDTH, GUI_HEIGHT, config
from flask import Flask, request, jsonify
from llm_index import LLMIndex
import json


# configure the AI agent
server = LangchainServer()
server.config.from_object(config)
server.config['AI_AGENT_NAME'] = AI_AGENT_NAME
server.config['AI_AGENT_VERSION'] = AI_AGENT_VERSION
server.config['AI_AGENT_DESCRIPTION'] = AI_AGENT_DESCRIPTION

# load config
with open('MLcopilot.json') as f:
    config = json.load(f)
    
# initialize llmindex
llm_index_obj = LLMIndex(config['llm'])

@app.route('/translate', methods=['POST'])
def translate():
    # Get the text to translate from the request body
    text = request.json['text']

    # Get the source and target languages from the request body
    source_language = request.json['source_language']
    target_language = request.json['target_language']

    # Use the LLMIndex object to translate the text
    translation = llm_index_obj.translate(text, source_language, target_language)

    # Return the translation in the response
    return jsonify({'translation': translation})

# define the routes
@server.route('/')
def index():
    return f'{server.config["AI_AGENT_NAME"]} v{server.config["AI_AGENT_VERSION"]} - {server.config["AI_AGENT_DESCRIPTION"]}'

@server.route('/runLangchain', methods=['POST'])
def run_langchain_api():
    data = server.request.json
    model_source = data.get('model_source', 'local')
    headers = {'Authorization': f'Bearer {server.config["LANGCHAIN_API_KEY"]}'} if model_source == 'local' else {}
    response = requests.post(f'{server.config["LANGCHAIN_URL"]}/completions' if model_source == 'local' else 'https://api.openai.com/v1/completions', headers=headers, json={'model': 'text-davinci-003' if model_source == 'openai' else 'distilgpt2' if model_source == 'huggingface' else 'local', 'prompt': data['text']})
    return jsonify({'message': 'Langchain executed successfully.', 'output': response.json()['choices'][0]['text'] if model_source != 'huggingface' else response.json()})

@server.route('/createFile', methods=['POST'])
def create_file_route():
    data = server.request.json
    return jsonify(create_file(data['fileName'], data['content']))

@server.route('/executeCommand', methods=['POST'])
def execute_command_route():
    data = server.request.json
    return jsonify(execute_command(data['commandName'], data['commandArgs']))

@server.route('/getEnvironmentDetails', methods=['GET'])
def get_environment_details_route():
    return jsonify(get_environment_details())

@server.route('/runValScript', methods=['POST'])
def run_val_script_api():
    data = server.request.json
    return jsonify(runValScript(data['scriptName']))

@server.route('/fetchInternet', methods=['GET'])
def fetch_internet_api():
    url = server.request.args.get('url')
    response = requests.get(url, timeout=server.config["LANGCHAIN_TIMEOUT"])
    return jsonify({'message': 'Internet accessed successfully.', 'data': response.text})

# run the server
if __name__ == '__main__':
    server.run(debug=True, title=GUI_TITLE, width=GUI_WIDTH, height=GUI_HEIGHT)