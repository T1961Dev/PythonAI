from flask import Flask, request, jsonify
from utils import create_file, execute_command, get_environment_details, runValScript, runLLM, runLangchain
from config import AI_AGENT_NAME, AI_AGENT_VERSION, AI_AGENT_DESCRIPTION, GUI_TITLE, GUI_WIDTH, GUI_HEIGHT, config
import requests

app = Flask(__name__)

# configure the AI agent
app.config.from_object(config)
app.config['AI_AGENT_NAME'] = AI_AGENT_NAME
app.config['AI_AGENT_VERSION'] = AI_AGENT_VERSION
app.config['AI_AGENT_DESCRIPTION'] = AI_AGENT_DESCRIPTION

def create_file_api():
    data = request.get_json()
    return jsonify(create_file(data['fileName'], data['content']))

def execute_command_api():
    data = request.get_json()
    return jsonify(execute_command(data['commandName'], data['commandArgs']))

def get_environment_details_api():
    return jsonify(get_environment_details())

@app.route('/')
def index():
    return f'{app.config["AI_AGENT_NAME"]} v{app.config["AI_AGENT_VERSION"]} - {app.config["AI_AGENT_DESCRIPTION"]}'

@app.route('/runLLM', methods=['POST'])
def run_llm_api():
    data = request.get_json()
    headers = {'Authorization': f'Bearer {app.config["OPENAI_API_KEY"]}'}
    response = requests.post('https://api.openai.com/v1/completions', headers=headers, json={'model': 'text-davinci-003', 'prompt': data['text']})
    return jsonify({'message': 'LLM executed successfully.', 'output': response.json()['choices'][0]['text']})

@app.route('/runLangchain', methods=['POST'])
def run_langchain_api():
    data = request.get_json()
    headers = {'Authorization': f'Bearer {app.config["LANGCHAIN_API_KEY"]}'}
    response = requests.post(f'{app.config["LANGCHAIN_URL"]}/completions', headers=headers, json={'model': 'text-davinci-003', 'prompt': data['text']})
    return jsonify({'message': 'Langchain executed successfully.', 'output': response.json()['choices'][0]['text']})

@app.route('/createFile', methods=['POST'])
def create_file_route():
    return create_file_api()

@app.route('/executeCommand', methods=['POST'])
def execute_command_route():
    return execute_command_api()

@app.route('/getEnvironmentDetails', methods=['GET'])
def get_environment_details_route():
    return get_environment_details_api()

@app.route('/runValScript', methods=['POST'])
def run_val_script_api():
    data = request.get_json()
    return jsonify(runValScript(data['scriptName']))

@app.route('/fetchInternet', methods=['GET'])
def fetch_internet_api():
    url = request.args.get('url')
    response = requests.get(url, timeout=app.config["LANGCHAIN_TIMEOUT"])
    return jsonify({'message': 'Internet accessed successfully.', 'data': response.text})

if __name__ == '__main__':
    app.run(debug=True, title=GUI_TITLE, width=GUI_WIDTH, height=GUI_HEIGHT)
